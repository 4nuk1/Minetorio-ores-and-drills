package com.example.minetorio;

public enum DrillTier {

    SMALL_3X3(2, 10, 32, 1, 1),
    LARGE_5X5(3, 15, 48, 2, 3);

    public final int platformHalf;   
    public final int height;
    public final float impactPerRpm;
    public final int oreBlocksPerCycle;
    public final int rawPerCycle;

    DrillTier(int platformHalf, int height, float impactPerRpm, int oreBlocksPerCycle, int rawPerCycle) {
        this.platformHalf = platformHalf;
        this.height = height;
        this.impactPerRpm = impactPerRpm;
        this.oreBlocksPerCycle = oreBlocksPerCycle;
        this.rawPerCycle = rawPerCycle;
    }
}
